namespace BattlefieldScripts.Actions
{
	public delegate int ParamIntDelegate();
}
