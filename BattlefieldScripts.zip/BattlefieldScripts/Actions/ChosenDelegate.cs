using System.Collections.Generic;
using UnityEngine;

namespace BattlefieldScripts.Actions
{
	public delegate void ChosenDelegate(Dictionary<Vector2, FieldMonster> monsters);
}
