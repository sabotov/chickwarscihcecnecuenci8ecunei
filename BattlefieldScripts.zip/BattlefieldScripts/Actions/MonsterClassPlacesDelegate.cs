using System.Collections.Generic;
using NewAssets.Scripts.DataClasses.MonsterParams;
using UnityEngine;

namespace BattlefieldScripts.Actions
{
	public delegate List<Vector2> MonsterClassPlacesDelegate(Class monClass);
}
