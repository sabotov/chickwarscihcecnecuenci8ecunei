using System;
using System.Collections.Generic;
using NewAssets.Scripts.UtilScripts;
using UnityEngine;
using UtilScripts;

namespace BattlefieldScripts.Actions
{
	public class TopAppearAnimation : BitActionAnimation
	{
		public override void Animate(Dictionary<Common.StringDelegate, FieldVisual> monstersAction, Action onEnded)
		{
			foreach (KeyValuePair<Common.StringDelegate, FieldVisual> item in monstersAction)
			{
				FieldMonsterVisual monster = item.Value as FieldMonsterVisual;
				if (monster != null)
				{
					monster.SetParamsVisible(visible: false);
					Debug.LogWarning("TopAppearAnimation isn't supported!");
					Common.VoidDelegate procedure = delegate
					{
						monster.SetParamsVisible(visible: true);
					};
					Initializer.WaitForProcedure(0.6f, procedure);
				}
				item.Key();
			}
			Initializer.WaitForProcedure(0.6f, delegate
			{
				onEnded();
			});
		}
	}
}
