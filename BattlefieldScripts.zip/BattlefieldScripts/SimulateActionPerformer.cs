namespace BattlefieldScripts
{
	public class SimulateActionPerformer : ArmyActionPerformer
	{
	}
}
