namespace BattlefieldScripts
{
	public enum MonsterAnimationType
	{
		Idle = 0,
		MeleeHit = 1,
		Damaged = 2,
		Death = 3,
		Victory = 4,
		RangedShot = 5
	}
}
