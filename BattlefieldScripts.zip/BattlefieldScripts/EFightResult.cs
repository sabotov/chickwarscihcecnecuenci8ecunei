namespace BattlefieldScripts
{
	public enum EFightResult
	{
		Win = 1,
		Lose = 0,
		Tie = -1
	}
}
