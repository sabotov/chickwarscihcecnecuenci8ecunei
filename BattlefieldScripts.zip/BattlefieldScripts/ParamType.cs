namespace BattlefieldScripts
{
	public enum ParamType
	{
		Attack = 0,
		Health = 1
	}
}
