namespace BattlefieldScripts
{
	public class StatChangeData
	{
		public FieldMonster.StatSnapshot prevSnapshot;

		public FieldMonster.StatSnapshot curSnapshot;
	}
}
