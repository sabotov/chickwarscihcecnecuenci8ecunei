namespace BattlefieldScripts.Core
{
	public enum ArmySide
	{
		Left = 0,
		Right = 1
	}
}
